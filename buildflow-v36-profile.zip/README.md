Buildflow v36 with Profile tab.

Only the Profile tab was added/activated on top of v36.
It contains personal profile info, project history, basic progress stats,
and recently finished projects. Profile data is stored locally.
